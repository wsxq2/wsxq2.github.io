import glob
import os
import time
from shutil import copyfile

import win32com.client
from PyPDF2 import PdfFileMerger


# changed from https://www.bbsmax.com/A/GBJrLR0Zd0/
def convert_to_pdf(in_dir=r"./docs/", out_dir=r""):
    # absolute path is needed
    # be careful about the slash '\', use '\\' or '/' or raw string r"..."
    if out_dir == r"":
        out_dir = os.path.join(in_dir, "pdf")
    in_dir = os.path.abspath(in_dir)
    out_dir = os.path.abspath(out_dir)

    wdFormatPDF = 17
    word = win32com.client.DispatchEx('Word.Application')
    word.Visible = False
    # print(word)
    time.sleep(3)
    first_flag = True

    for root, dirs, files in os.walk(in_dir, topdown=False):
        for file in files:
            in_file = os.path.join(root, file)
            # print(in_dir)
            out_file_temp = os.path.join(out_dir, file)
            if (file.endswith(".docx") or file.endswith(".doc")) and (not file.startswith('~')):
                out_file = out_file_temp.rsplit('.', 1)[0] + '.pdf'
                # print(in_file)
                #            print(out_file)
                # skip existed files
                if os.path.isfile(out_file):
                    continue
                print("converting '" + in_file + "' into '" + out_file + "'")
                doc = word.Documents.Open(in_file)
                # print(type(doc))
                doc.SaveAs2(out_file, FileFormat=wdFormatPDF)
                doc.Close()
                if first_flag:
                    word.Visible = False
                    first_flag = False
            elif file.endswith(".pdf"):
                print("coping '" + in_file + "' into '" + out_file_temp + "'")
                copyfile(in_file, out_file_temp)

    word.Quit()
    print("Conversion Done.")


# changed from https://stackoverflow.com/a/47356404
def merge_pdf(in_dir=r"./pdf/", out_file=r""):
    if out_file == r"":
        out_file = os.path.join(in_dir, "../../merged.pdf")
    x = [a for a in os.listdir(in_dir) if a.endswith(".pdf")]
    print(x)

    merger = PdfFileMerger()

    for pdf in x:
        merger.append(open(os.path.join(in_dir, pdf), 'rb'))

    with open(out_file, "wb") as fout:
        merger.write(fout)


def handle_bysj():
    doc_path = r"C:\Users\wsxq2\Documents\MY\workspace\da_si_xia\bysj\毕业设计表格全套\out"
    pdf_path = os.path.join(doc_path, "pdf")

    # clear output path
    files = glob.glob(os.path.join(pdf_path, "*"))
    for file in files:
        os.remove(file)

    # convert doc to pdf
    convert_to_pdf(in_dir=doc_path, out_dir=pdf_path)

    # merge all pdf to merged.pdf
    merge_pdf(pdf_path, os.path.join(doc_path, "../merged.pdf"))


def test():
    doc_path = r"C:\Users\wsxq2\Documents\MY\workspace\da_si_xia\bysj\毕业设计表格全套\out"
    pdf_path = os.path.join(doc_path, "pdf")
    convert_to_pdf(in_dir=doc_path, out_dir=pdf_path)


if __name__ == '__main__':
    # convert_to_pdf()
    # merge_pdf()
    handle_bysj()
    # test()
