## 毕设归档资料各个 doc 文件分别生成 PDF 并合并为最终 pdf

建议使用 `virtualenv` 以避免将系统的 Python 库弄乱。本教程使用 Powershell（其实更推荐最新的微软开发的跨平台的 powershell），CMD 亲测不可行（`.\venv\Scripts\activate`这一步会失败，虽然看起来成功了）

1. 切换下载源：默认的源在国外，下载很慢，因此建议切换到国内源，如清华的。Windows 中编辑 `%APPDATA%\pip\pip.ini` 文件如下即可（没有该文件及父目录就手动创建）：
   ```
   [global]
   timeout = 60
   index-url = https://pypi.tuna.tsinghua.edu.cn/simple
   ```
   详情参见后面的**温馨提示**。
1. 安装 `virtualenv`:
   ```
   pip3 install virtualenv
   ```
1. 解压本项目到特定文件夹
1. 切换到该文件夹:
   ```
   cd .\doc2pdf
   ```
1. 创建一个 `virtualenv` 环境：
   ```
   virtualenv venv
   ```

1. 进入该环境：
   ```
   .\venv\Scripts\activate
   ```
1. 安装依赖：
   ```
   pip3 install -r requirements.txt
   ```
1. 修改脚本中的变量：将`doc_path`改为正确的位置即可。另请手动创建`$doc_path\pdf`目录。
1. 运行脚本（运行前请关闭 Word 程序）：
   ```
   python main.py
   ```
1. 查看结果：在`$doc_path\pdf\`中为 pdf 文件，在`$doc_path\..\`中包含最终输出`merged.pdf`

**温馨提示**：如果下载依赖时太慢，可考虑修改 Python 的 `index-url`：
1. 临时修改：使用 `-i` 参数（ `--index-url`）。例如：
   ```
   $ pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple/ SomePackage
   ```
1. 永久修改：修改 `%APPDATA%\pip\pip.ini` 内容如下（以 Windows 为例，其它平台的配置文件的位置参见 <https://pip.pypa.io/en/stable/user_guide/#config-file> ）：
   ```
   [global]
   timeout = 60
   index-url = https://pypi.tuna.tsinghua.edu.cn/simple/
   ```

   常用国内源：
   * 阿里云 http://mirrors.aliyun.com/pypi/simple/
   * 中国科技大学 https://pypi.mirrors.ustc.edu.cn/simple/
   * 豆瓣(douban) http://pypi.douban.com/simple/
   * 清华大学 https://pypi.tuna.tsinghua.edu.cn/simple/
   * 中国科学技术大学 http://pypi.mirrors.ustc.edu.cn/simple/
   
   详情可参考 <https://yq.aliyun.com/articles/652884>